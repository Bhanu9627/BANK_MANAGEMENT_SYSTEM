import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Bank bank = new Bank();
        Scanner scanner = new Scanner(System.in);
        
        while (true) {
            System.out.println("\nBank Management System");
            System.out.println("1. Create Account");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Check Balance");
            System.out.println("5. Display All Accounts");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            
            try {
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                
                switch (choice) {
                    case 1:
                        System.out.print("Enter account number: ");
                        String accNumber = scanner.nextLine();
                        System.out.print("Enter account holder name: ");
                        String accHolder = scanner.nextLine();
                        System.out.print("Enter initial balance: ");
                        double initialBalance = scanner.nextDouble();
                        bank.addAccount(new Account(accNumber, accHolder, initialBalance));
                        break;
                        
                    case 2:
                        System.out.print("Enter account number: ");
                        String depositAcc = scanner.nextLine();
                        Account depositAccount = bank.findAccount(depositAcc);
                        if (depositAccount != null) {
                            System.out.print("Enter deposit amount: ");
                            double depositAmount = scanner.nextDouble();
                            depositAccount.deposit(depositAmount);
                        } else {
                            System.out.println("Account not found.");
                        }
                        break;
                        
                    case 3:
                        System.out.print("Enter account number: ");
                        String withdrawAcc = scanner.nextLine();
                        Account withdrawAccount = bank.findAccount(withdrawAcc);
                        if (withdrawAccount != null) {
                            System.out.print("Enter withdrawal amount: ");
                            double withdrawAmount = scanner.nextDouble();
                            withdrawAccount.withdraw(withdrawAmount);
                        } else {
                            System.out.println("Account not found.");
                        }
                        break;
                        
                    case 4:
                        System.out.print("Enter account number: ");
                        String balanceAcc = scanner.nextLine();
                        Account balanceAccount = bank.findAccount(balanceAcc);
                        if (balanceAccount != null) {
                            System.out.println("Current balance: " + balanceAccount.getBalance());
                        } else {
                            System.out.println("Account not found.");
                        }
                        break;
                        
                    case 5:
                        bank.displayAllAccounts();
                        break;
                        
                    case 6:
                        System.out.println("Exiting the system. Thank you!");
                        scanner.close();
                        System.exit(0);
                        break;
                        
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (Exception e) {
                System.err.println("Error: " + e.getMessage());
                scanner.nextLine(); // Clear invalid input
            }
        }
    }
}