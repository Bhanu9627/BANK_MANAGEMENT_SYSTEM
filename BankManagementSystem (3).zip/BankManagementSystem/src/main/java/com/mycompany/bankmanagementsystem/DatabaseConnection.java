import java.sql.*;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

public class DatabaseConnection {
    private static HikariDataSource dataSource;

    static {
        try {
            HikariConfig config = new HikariConfig();
            config.setJdbcUrl("jdbc:mysql://localhost:3306/bank_management_system");
            config.setUsername("root");
            config.setPassword("root"); // Change to your password
            config.setDriverClassName("com.mysql.cj.jdbc.Driver");
            config.addDataSourceProperty("cachePrepStmts", "true");
            config.addDataSourceProperty("prepStmtCacheSize", "250");
            config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
            
            // Additional connection test
            config.setConnectionTestQuery("SELECT 1");
            config.setInitializationFailTimeout(30000); // 30 seconds timeout
            
            dataSource = new HikariDataSource(config);
            
            // Test connection immediately
            try (Connection conn = dataSource.getConnection()) {
                System.out.println("Successfully connected to database!");
            }
        } catch (Exception e) {
            System.err.println("ERROR: Failed to initialize database connection");
            System.err.println("Please verify:");
            System.err.println("1. MySQL is running");
            System.err.println("2. Database 'bank_management_system' exists");
            System.err.println("3. Username and password are correct");
            System.err.println("4. MySQL user has proper privileges");
            System.err.println("Original error: " + e.getMessage());
            throw new ExceptionInInitializerError(e);
        }
    }

    public static Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }
}