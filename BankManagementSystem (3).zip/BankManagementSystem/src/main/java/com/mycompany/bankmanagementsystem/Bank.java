import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Bank {
    // Initialize database table
    static {
        try {
            String sql = "CREATE TABLE IF NOT EXISTS accounts (" +
                         "account_number VARCHAR(20) PRIMARY KEY, " +
                         "account_holder VARCHAR(100) NOT NULL, " +
                         "balance DOUBLE NOT NULL)";
            try (Connection conn = DatabaseConnection.getConnection();
                 Statement stmt = conn.createStatement()) {
                stmt.execute(sql);
            }
        } catch (SQLException e) {
            System.err.println("Error creating table: " + e.getMessage());
        }
    }

    // Add a new account
    public void addAccount(Account account) {
        try {
            account.save();
            System.out.println("Account added successfully.");
        } catch (SQLException e) {
            System.err.println("Error adding account: " + e.getMessage());
        }
    }

    // Find account by account number
    public Account findAccount(String accountNumber) {
        String sql = "SELECT * FROM accounts WHERE account_number = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, accountNumber);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Account(
                        rs.getString("account_number"),
                        rs.getString("account_holder"),
                        rs.getDouble("balance")
                    );
                }
            }
        } catch (SQLException e) {
            System.err.println("Error finding account: " + e.getMessage());
        }
        return null;
    }

    // Display all accounts
    public void displayAllAccounts() {
        List<Account> accounts = new ArrayList<>();
        String sql = "SELECT * FROM accounts";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                accounts.add(new Account(
                    rs.getString("account_number"),
                    rs.getString("account_holder"),
                    rs.getDouble("balance")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching accounts: " + e.getMessage());
        }

        if (accounts.isEmpty()) {
            System.out.println("No accounts in the bank.");
        } else {
            System.out.println("\n--- All Accounts ---");
            for (Account account : accounts) {
                System.out.println(account);
                System.out.println("---------------------");
            }
        }
    }
}